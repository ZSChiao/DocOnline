# ZoieC's English-Notes

> 本仓库被用来记录我的英语学习笔记。
:on: 在线预览版笔记：http://english-notes.zoiec.ml/#/