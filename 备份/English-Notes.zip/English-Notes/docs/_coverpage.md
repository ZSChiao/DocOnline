![](https://i.loli.net/2020/06/19/5PfZmF4GSkOyBuo.png)

# 英语学习笔记  

- 本文档记录了作者在的英语学习历程，侧重点倾向于笔记记录，如果本文能为您得到帮助，请给予支持！  

  ![stars](https://badgen.net/github/stars/ZSChiao/DocOnline?icon=github&color=4ab8a1) ![forks](https://badgen.net/github/forks/ZSChiao/DocOnline?icon=github&color=4ab8a1) 

[GitHub](<https://github.com/ZSChiao/DocOnline>)  [开始阅读](README.md)